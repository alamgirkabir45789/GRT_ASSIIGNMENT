import './App.css';

import OrderForm from './components/order/OrderForm';

function App() {

  return (
    <div className="container-fluid">
      <div className='card p-5'>
<div className='card-header bg-light text-muted'>
  <h1 className='text-center'>Master Details Order Management System</h1>
</div>
<OrderForm/>
      </div>
      

    
    </div>
  );
}

export default App;
