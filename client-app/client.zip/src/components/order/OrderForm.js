import React, { useEffect, useState } from "react";
import { PlusCircle, Trash2 } from "react-feather";
import Select from "react-select";
import { Button, Col, FormGroup, Input, Label, Row, Table } from "reactstrap";
import { baseAxios } from "../../utils";
import OrderList from "./OrderList";

const pMethods = [
  { label: "Cash", value: "Cash" },
  { label: "Card", value: "Card" },
];

const OrderForm = () => {
  const [customerList, setCustomerList] = useState([]);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [productList, setProductList] = useState([]);
  const [selectedProductName, setSelectedProductName] = useState();
  const [selectedPaymentMetod, setSelectedPaymentMetod] = useState(null);
  const [orderList, setOrderList] = useState([]);
  const [grandTotal, setGrandTotal] = useState(0);
  const [orderNumber, setOrderNumber] = useState("");
  const [orderDetails, setOrderDetails] = useState([]);
  const [isEdit, setIsEdit] = useState(false);
  const [orderMasterId, setOrderMasterId] = useState();
  const [deleteOrderProductId, setDeleteOrderProductId] = useState([]);

  const getAllCustomer = async () => {
    const res = await baseAxios.get("/api/Customer");
    const customerDdl = res.data.map((item) => ({
      ...item,
      label: item.customerName,
      value: item.customerID,
    }));
    setCustomerList(customerDdl);
  };

  const getAllProduct = async () => {
    const res = await baseAxios.get("/api/Product");
    const productDdl = res.data.map((item) => ({
      ...item,
      label: item.productName,
      value: item.productId,
    }));
    setProductList(productDdl);
  };
  useEffect(() => {
    getAllCustomer();
  }, []);

  useEffect(() => {
    getAllProduct();
  }, []);
  const getOrderDetails = async () => {
    const res = await baseAxios.get("/api/OrderMaster");
    setOrderDetails(res.data);
  };
  useEffect(() => {
    getOrderDetails();
  }, []);

  useEffect(() => {
    if (orderList.length > 0) {
      const gTotal = orderList.reduce(
        (acc, curr) => acc + curr.price * curr.quantity,
        0
      );
      setGrandTotal(gTotal);
    }
  }, [orderList]);

  const handleAddOrder = () => {
    const payload = {
      id: selectedProductName?.value,
      name: selectedProductName?.label,
      price: selectedProductName?.price,
      quantity: 1,
    };
    if (payload.id) {
      setOrderList([...orderList, payload]);

      const remainingDdlProduct = productList.filter(
        (f) => f.productId !== payload.id
      );

      setProductList(remainingDdlProduct);
      setSelectedProductName(null);
    }
  };
  const handleDeleteProduct = (index) => {
    const _orderList = [...orderList];
    const _productList = [...productList];
    const selectedOrder = _orderList[index];
    if (selectedOrder.orderDetailId) {
      const deletedId = selectedOrder.orderDetailId;
      setDeleteOrderProductId([...deleteOrderProductId, deletedId]);
    }
    _orderList.splice(index, 1);
    setOrderList(_orderList);
    _productList.push({
      productId: selectedOrder.id,
      label: selectedOrder.name,
      value: selectedOrder.id,
      price: selectedOrder.price,
    });

    setProductList(_productList);
  };

  const handleQuatityChange = (e, index) => {
    const _orderList = [...orderList];
    const selectedOrder = _orderList[index];
    let inputVal = Number(e.target.value);
    selectedOrder.quantity = inputVal;

    _orderList[index] = selectedOrder;
    setOrderList(_orderList);
  };

  const handleEdiOrder = async (id) => {
    const res = await baseAxios.get(`/api/OrderMaster/${id}`);
    const modifiedOrderList = res.data.orderDetails.map((item) => ({
      ...item,
      name: item.productName,
      id: item.productId,
      price: item.productPrice,
      quantity: item.quantity,
    }));
    setIsEdit(true);
    setOrderList(modifiedOrderList);
    setGrandTotal(res.data.gTotal);
    setOrderNumber(res.data.orderNumber);
    setSelectedPaymentMetod(pMethods.find((f) => f.label === res.data.pMethod));
    setSelectedCustomer(
      customerList.find((f) => f.customerID === res.data.customerId)
    );
    setOrderMasterId(id);
  };
  const handleDeleteOrder = async (id) => {
    if (id) {
      alert("Are you sure, you want to delete this item!!!");
      await baseAxios.delete(`/api/OrderMaster/${id}`);
      getOrderDetails();
    }
  };
  const resetFormState = () => {
    setOrderNumber("");
    setSelectedPaymentMetod(null);
    setSelectedCustomer(null);
    setGrandTotal(0);
    setOrderList([]);
    setIsEdit(false);
  };
  const handleSubmit = async () => {
    if (isEdit) {
      const payload = {
        orderMasterId: Number(orderMasterId),
        orderNumber: orderNumber,
        customerId: selectedCustomer?.value,
        pMethod: selectedPaymentMetod?.label,
        gTotal: grandTotal,
        deletedOrderItemIds: deleteOrderProductId.join(","),
        orderDetails: orderList?.map((opt) => ({
          orderMasterId: opt.orderMasterId ? opt.orderMasterId : 0,
          orderDetailId: opt.orderDetailId ? opt.orderDetailId : 0,
          productId: opt?.id,
          quantity: opt.quantity,
          productPrice: opt?.price,
          productName: opt?.name,
        })),
      };
      console.log(JSON.stringify(payload, null, 2));

      if (
        payload.orderNumber !== "" &&
        payload.grandTotal !== 0 &&
        payload.orderDetails.length !== 0
      ) {
        const res = await baseAxios.put(
          `/api/OrderMaster/${orderMasterId}`,
          payload
        );
        if (res.status === 200) {
          alert("Data Updated");
          getOrderDetails();
          resetFormState();
        } else {
          alert("Something went wrong!");
        }
      } else {
        alert("Provide all Informations");
      }
    } else {
      const payload = {
        orderNumber: orderNumber,
        customerId: selectedCustomer?.value,
        pMethod: selectedPaymentMetod?.label,
        gTotal: grandTotal,
        orderDetails: orderList?.map((opt) => ({
          productId: opt?.id,
          quantity: opt.quantity,
          productPrice: opt?.price,
          productName: opt?.name,
        })),
      };
      console.log(JSON.stringify(payload, null, 2));

      if (
        payload.orderNumber !== "" &&
        payload.grandTotal !== 0 &&
        payload.orderDetails.length !== 0
      ) {
        const res = await baseAxios.post("/api/OrderMaster", payload);
        if (res.data) {
          alert("Success");
          getOrderDetails();
          resetFormState();
        } else {
          alert("Something went wrong!");
        }
      } else {
        alert("Provide all Informations");
      }
    }
  };

  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-md-7">
          <div className="card  mt-3">
            <div className="card-header">
              <p className="text-center">Order Form</p>
            </div>
            <div className="card-body p-2">
              <Row>
                <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                  <Row>
                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                      <FormGroup>
                        <Label for="name">Order Number</Label>
                        <Input
                          name="name"
                          id="name"
                          type="text"
                          value={orderNumber}
                          onChange={(e) => setOrderNumber(e.target.value)}
                        />
                      </FormGroup>
                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                      <FormGroup>
                        <Label for="paymentMethod">
                          Select Payment Method{" "}
                        </Label>
                        <Select
                          id="paymentMethod"
                          isClearable
                          isSearchable
                          classNamePrefix="select"
                          options={pMethods}
                          value={selectedPaymentMetod}
                          onChange={(data) => setSelectedPaymentMetod(data)}
                        />
                      </FormGroup>
                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                      <FormGroup>
                        <Label for="customerName">Customer Name</Label>
                        <Select
                          id="customerName"
                          isClearable
                          isSearchable
                          classNamePrefix="select"
                          options={customerList}
                          value={selectedCustomer}
                          onChange={(data) => setSelectedCustomer(data)}
                        />
                      </FormGroup>
                    </Col>

                    <Col xs={6} sm={6} md={6} lg={6} xl={6}>
                      <FormGroup>
                        <Label for="name">Grand Total</Label>
                        <Input
                          name="name"
                          id="name"
                          type="text"
                          disabled
                          value={grandTotal}
                        />
                      </FormGroup>
                    </Col>
                  </Row>
                </Col>

                <Col xs={10} sm={10} md={10} lg={10} xl={10}>
                  <FormGroup>
                    <Label for="productName">Product Name</Label>
                    <Select
                      id="productName"
                      isClearable
                      isSearchable
                      classNamePrefix="select"
                      options={productList}
                      value={selectedProductName}
                      onChange={(data) => setSelectedProductName(data)}
                    />
                  </FormGroup>
                </Col>
                <Col xs={2} sm={2} md={2} lg={2} xl={2}>
                  <FormGroup style={{ marginTop: "1.5rem" }}>
                    <Button
                      style={{ padding: "10px" }}
                      color="primary"
                      size="sm"
                      id="btnAdd"
                      type="button"
                      outline
                      onClick={handleAddOrder}
                    >
                      <PlusCircle id="btnAdd" size={16} />
                    </Button>
                  </FormGroup>
                </Col>
              </Row>

              {orderList.length > 0 && (
                <Table responsive={true} bordered>
                  <thead className="thead-dark">
                    <tr>
                      <th>Product Name</th>
                      <th>Price</th>
                      <th>Quantity</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {orderList?.map((op, index) => (
                      <tr key={index + 1}>
                        <td style={{ width: "300px" }}>{op?.name}</td>
                        <td style={{ width: "300px" }}>{op?.price}</td>
                        <td style={{ width: "300px" }}>
                          <Input
                            name="quatity"
                            id="quantity"
                            type="number"
                            min={1}
                            defaultValue={op?.quantity}
                            onChange={(e) => handleQuatityChange(e, index)}
                          />
                        </td>

                        <td style={{ width: "50px" }}>
                          <Button
                            color="danger"
                            size="sm"
                            id="btnRemove"
                            type="button"
                            outline
                            onClick={() => handleDeleteProduct(index, op)}
                          >
                            <Trash2
                              id="btnRemove"
                              className="text-danger"
                              size={12}
                            />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </Table>
              )}
            </div>

            <div className="card-footer d-flex justify-content-between">
              <Button
                type="reset"
                outline
                color="secondary"
                className="mr-1"
                onClick={resetFormState}
              >
                Reset
              </Button>
              {isEdit ? (
                <Button
                  type="submit"
                  color="primary"
                  className="mr-1"
                  onClick={handleSubmit}
                >
                  Update
                </Button>
              ) : (
                <Button
                  type="submit"
                  color="primary"
                  className="mr-1"
                  onClick={handleSubmit}
                >
                  Submit
                </Button>
              )}
            </div>
          </div>
        </div>
        <div className="col-md-5">
          <OrderList
            orderDetails={orderDetails}
            handleDeleteOrder={handleDeleteOrder}
            handleEdiOrder={handleEdiOrder}
          />
        </div>
      </div>
    </div>
  );
};

export default OrderForm;
