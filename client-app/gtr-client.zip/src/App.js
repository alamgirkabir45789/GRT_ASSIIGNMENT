import "./App.css";
import CustomAPI from "./components/custom-api/CustomAPI";
import OrderForm from "./components/order/OrderForm";

function App() {
  return (
    <div className="container-fluid">
      <div className="card p-2">
        <div className="card-header bg-light text-muted">
          <h1 className="text-center">
            Master Details Order Management System
          </h1>
        </div>
        <OrderForm />
      </div>
      <div>
        <CustomAPI />
      </div>
    </div>
  );
}

export default App;
