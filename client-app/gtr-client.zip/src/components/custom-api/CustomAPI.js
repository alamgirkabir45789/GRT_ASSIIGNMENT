import axios from "axios";
import React, { useEffect, useState } from "react";
import { Table } from "reactstrap";
const CustomAPI = () => {
  const [productList, setProductList] = useState([]);
  console.log(productList);
  const getAllProduct = async () => {
    const res = await axios.get(
      "https://www.pqstec.com/InvoiceApps/values/GetProductListAll"
    );
    const productDdl = res.data.map((item) => ({
      ...item,
      label: item.productName,
      value: item.productId,
    }));
    setProductList(productDdl);
  };
  useEffect(() => {
    getAllProduct();
  }, []);
  return (
    <div className="card mt-2">
      <div className="card-header ">
        <h2 className="text-center">Custom API Integration</h2>
      </div>
      <div className="card-body">
        {productList.length > 0 && (
          <Table responsive={true} bordered>
            <thead className="thead-dark">
              <tr>
                <th>Brand Name</th>
                <th> Name</th>
                <th>Category Name</th>
                <th>Code</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              {productList?.map((op, index) => (
                <tr key={index + 1}>
                  <td>{op?.BrandName}</td>
                  <td>{op?.Name}</td>
                  <td>{op?.CategoryName}</td>
                  <td>{op?.Code}</td>
                  <td>{op?.Price}</td>
                </tr>
              ))}
            </tbody>
          </Table>
        )}
      </div>
    </div>
  );
};

export default CustomAPI;
