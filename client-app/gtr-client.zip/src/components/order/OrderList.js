import React,{useState,useEffect} from 'react'
import axios from 'axios'
import { Button, Col, FormGroup,Input, Label, Row, Table } from 'reactstrap';
import { Edit2, PlusCircle, Trash2 } from 'react-feather';
const OrderList = ({orderDetails,handleDeleteOrder,handleEdiOrder}) => {

  return (
    <div className='card mt-3 '>
      <div className='card-header '>
<p className='text-center'>Order List</p>
      </div>
      <div className='card-body'>

      {orderDetails.length > 0 && (
        <Table responsive={true} bordered>
          <thead className="thead-dark">
            <tr>
              <th>Order Number</th>
              <th>Customer Name</th>
              <th>Payment Method</th>
              <th>Grand Total</th>

              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {orderDetails?.map((op, index) => (
              <tr key={op.orderMasterId}>
                <td style={{ width: '300px' }}>{op?.orderNumber}</td>
                <td style={{ width: '300px' }}>{op?.customer.customerName}</td>
                <td style={{ width: '300px' }}>{op?.pMethod}</td>
                <td >{op?.gTotal}</td>
                


                <td style={{ width: '100px' ,display:'flex',gap:'2px'}}>
                <Button color="danger" size="sm" id="btnRemove" type="button" outline onClick={() => handleEdiOrder(op.orderMasterId)}>
                    <Edit2 id="btnRemove" className="text-danger" size={12} />
                  </Button>
                  <Button color="danger" size="sm" id="btnRemove" type="button" outline onClick={() => handleDeleteOrder(op.orderMasterId)}>
                    <Trash2 id="btnRemove" className="text-danger" size={12} />
                  </Button>
                </td>
              </tr>
            ))}
          </tbody>
        </Table>
      )}
      </div>
    </div>
  )
}

export default OrderList