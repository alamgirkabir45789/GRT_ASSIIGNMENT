import axios from "axios";

export const {
  REACT_APP_MERCHANDISING_BASE_URL,
  REACT_APP_BASE_URL,
  REACT_APP_AUTH_BASE_URL,
} = process.env;

export const baseUrl = REACT_APP_BASE_URL;
export const baseAxios = axios.create({
  baseURL: baseUrl,
});
